package com.example.flower.Model;

public class Mawar extends Bunga {

    public Mawar(String nama, String asal, String deskripsi, int drawableRes) {
        super("Mawar",nama,asal,deskripsi,drawableRes);

    }

}