package com.example.flower.Model;

public class Melati extends Bunga {

    public Melati(String nama, String asal, String deskripsi, int drawableRes) {
        super("Melati",nama,asal,deskripsi,drawableRes);

    }

}