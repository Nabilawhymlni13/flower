package com.example.flower;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import com.example.flower.Model.Bunga;

public class GaleriActivity extends AppCompatActivity {

    List<Bunga> bungas;
    int indeksTampil = 0;
    String jenisBunga;
    Button btnPertama,btnTerakhir,btnSebelumnya,btnBerikutnya;
    TextView txJenis,txAsal,txDeskripsi,txJudul;
    ImageView ivFotoBunga;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil_bentuk);
        Intent intent = getIntent();
        jenisBunga = intent.getStringExtra(MainActivity.JENIS_GALERI_KEY);
        bungas = DataProvider.getBungasByTipe(this,jenisBunga);
        inisialisasiView();
        tampilkanProfil();
    }

    private void inisialisasiView() {
        btnPertama = findViewById(R.id.btnPertama);
        btnSebelumnya = findViewById(R.id.btnSebelumnya);
        btnBerikutnya = findViewById(R.id.btnBerikutnya);
        btnTerakhir = findViewById(R.id.btnTerakhir);

        btnPertama.setOnClickListener(view -> bungaPertama());
        btnTerakhir.setOnClickListener(view -> bungaTerakhir());
        btnSebelumnya.setOnClickListener(view -> bungaSebelumnya());
        btnBerikutnya.setOnClickListener(view -> bungaBerikutnya());

        txJenis = findViewById(R.id.txJenis);
        txAsal = findViewById(R.id.txAsal);
        txDeskripsi = findViewById(R.id.txDeskripsi);
        ivFotoBunga = findViewById(R.id.gambarBunga);

        txJudul = findViewById(R.id.txJudul);
        txJudul.setText("Berbagai Macam Bunga "+jenisBunga);
    }


    private void tampilkanProfil() {
        Bunga b = bungas.get(indeksTampil);
        Log.d("MAWAR","Menampilkan mawar "+b.getJenis());
        txJenis.setText(b.getJenis());
        txAsal.setText(b.getAsal());
        txDeskripsi.setText(b.getDeskripsi());
        ivFotoBunga.setImageDrawable(this.getDrawable(b.getDrawableRes()));
    }

    private void bungaPertama() {
        int posAwal = 0;
        if (indeksTampil == posAwal) {
            Toast.makeText(this,"Sudah di posisi pertama",Toast.LENGTH_SHORT).show();
            return;
        } else {
            indeksTampil = posAwal;
            tampilkanProfil();
        }
    }

    private void bungaTerakhir() {
        int posAkhir = bungas.size() - 1;
        if (indeksTampil == posAkhir) {
            Toast.makeText(this,"Sudah di posisi terakhir",Toast.LENGTH_SHORT).show();
            return;
        } else {
            indeksTampil = posAkhir;
            tampilkanProfil();
        }
    }

    private void bungaBerikutnya() {
        if (indeksTampil == bungas.size() - 1) {
            Toast.makeText(this,"Sudah di posisi terakhir",Toast.LENGTH_SHORT).show();
            return;
        } else {
            indeksTampil++;
            tampilkanProfil();
        }
    }

    private void bungaSebelumnya() {
        if (indeksTampil == 0) {
            Toast.makeText(this,"Sudah di posisi pertama",Toast.LENGTH_SHORT).show();
            return;
        } else {
            indeksTampil--;
            tampilkanProfil();
        }
    }
}