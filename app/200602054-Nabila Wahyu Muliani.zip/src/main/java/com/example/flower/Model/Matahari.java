package com.example.flower.Model;

public class Matahari extends Bunga {

    public Matahari(String nama, String asal, String deskripsi, int drawableRes) {
        super("Matahari",nama,asal,deskripsi,drawableRes);

    }

}